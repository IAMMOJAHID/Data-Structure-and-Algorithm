package Includes;

public class KeyNotFoundException extends Exception{
    public KeyNotFoundException() {  
        System.out.println("KeyNotFound"); 
    }  
}  