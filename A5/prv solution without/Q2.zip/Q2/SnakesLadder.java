import java.io.*;
import java.util.*;

public class SnakesLadder extends AbstractSnakeLadders {
	int N, M;
	int snakes[];
	int ladders[];
	
	public SnakesLadder(String name)throws Exception{
		File file = new File(name);
		BufferedReader br = new BufferedReader(new FileReader(file));
		N = Integer.parseInt(br.readLine());
        
        M = Integer.parseInt(br.readLine());

	    snakes = new int[N];
		ladders = new int[N];
	    for (int i = 0; i < N; i++){
			snakes[i] = -1;
			ladders[i] = -1;
		}

		for(int i=0;i<M;i++){
            String e = br.readLine();
            StringTokenizer st = new StringTokenizer(e);
            int source = Integer.parseInt(st.nextToken());
            int destination = Integer.parseInt(st.nextToken());

			if(source<destination){
				ladders[source] = destination;
			}
			else{
				snakes[source] = destination;
			}
        }
	}
    
	public int OptimalMoves(){
		int ans=100;
		int check[]=new int[N+1];
		for (int i=0; i<N+1; ++i){check[i]=100;}
		Queue<Integer> que_ins= new LinkedList<>(); 
		Queue<Integer> que_ans= new LinkedList<>();
		que_ins.add(0);
		que_ans.add(0);
		while(que_ins.isEmpty()==false){
			Integer tem=que_ins.poll();
			Integer ans1=que_ans.poll();
			if(tem==N && ans1<ans){
				ans=ans1;
			}
			if(tem<N && ladders[tem]!=-1 && check[ladders[tem]]>ans1){
				que_ins.add(ladders[tem]);
				que_ans.add(ans1);
				check[ladders[tem]]=ans1;
			}
			if(tem<N && snakes[tem]!=-1 && check[snakes[tem]]>ans1){
				que_ins.add(snakes[tem]);
				que_ans.add(ans1);
				check[snakes[tem]]=ans1;
			}
			if(tem+6<=N && check[tem+6]>ans1+1 && ladders[tem]==-1 && snakes[tem]==-1){
				que_ins.add(tem+6);
				check[tem+6]=ans1+1;
				que_ans.add(ans1+1);
			}
			if(tem+5<=N && check[tem+5]>ans1+1 && ladders[tem]==-1 && snakes[tem]==-1){
				que_ins.add(tem+5);
				check[tem+5]=ans1+1;
				que_ans.add(ans1+1);
			}
			if(tem+4<=N && check[tem+4]>ans1+1 && ladders[tem]==-1 && snakes[tem]==-1){
				que_ins.add(tem+4);
				check[tem+4]=ans1+1;
				que_ans.add(ans1+1);
			}
			if( tem+3<=N && check[tem+3]>ans1+1 && ladders[tem]==-1 && snakes[tem]==-1){
				que_ins.add(tem+3);
				check[tem+3]=ans1+1;
				que_ans.add(ans1+1);
			}
			if(tem+2<=N && check[tem+2]>ans1+1 && ladders[tem]==-1 && snakes[tem]==-1){
				que_ins.add(tem+2);
				check[tem+2]=ans1+1;
				que_ans.add(ans1+1);
			}
			if( tem+1<=N && check[tem+1]>ans1+1 && ladders[tem]==-1 && snakes[tem]==-1){
				que_ins.add(tem+1);
				check[tem+1]=ans+1;
				que_ans.add(ans1+1);
			}
		}
		return ans;
	}

	public int Query(int x, int y){
		int prv=OptimalMoves();
		if(x<y){
			this.ladders[x]=y;
			int now=OptimalMoves();
			if(now<prv){return 1;}
			else{return -1;}
		}
		else{
			this.snakes[x]=y;
			int now=OptimalMoves();
			if(now<prv){return 1;}
			else{return -1;}
		}
	}

	public int[] FindBestNewSnake(){
		int result[] = {-1, -1};
		int prv=OptimalMoves();
		int n=ladders.length;
		for(int i=0; i<n; ++i){
			if(ladders[i]!=-1){
				for(int j=i+1; j<n; ++j){
					if(ladders[j]!=-1){
						if(ladders[i]>j){
							snakes[ladders[i]]=j;
							int now=OptimalMoves();
							if(now<prv){result[0]=ladders[i]; result[1]=j; prv=now;}
							snakes[ladders[i]]=-1;
						}
						else if(ladders[j]<i){
							snakes[ladders[j]]=i;
							int now=OptimalMoves();
							if(now<prv){result[0]=ladders[j]; result[1]=i; prv=now;}
							snakes[ladders[j]]=-1;
						}
					}
				}
			}
		}
		return result;
	}
}